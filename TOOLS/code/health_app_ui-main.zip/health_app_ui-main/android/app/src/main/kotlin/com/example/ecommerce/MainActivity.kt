package com.example.ecommerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
